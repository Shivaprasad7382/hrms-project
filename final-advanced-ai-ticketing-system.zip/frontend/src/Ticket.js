
import React,{useState} from "react";
import axios from "axios";
import {Card,CardContent,TextField,Button,Typography} from "@mui/material";

export default function Ticket(){
  const [text,setText]=useState("");
  const [res,setRes]=useState(null);

  const submit=async()=>{
    const r=await axios.post("http://127.0.0.1:8000/ticket",{description:text});
    setRes(r.data);
  }

  return (
    <div>
      <Card><CardContent>
        <TextField fullWidth multiline rows={4} onChange={(e)=>setText(e.target.value)} />
        <Button onClick={submit} variant="contained" style={{marginTop:10}}>Submit</Button>
      </CardContent></Card>

      {res && <Card style={{marginTop:20}}><CardContent>
        <Typography>Category: {res.ai.category}</Typography>
        <Typography>Severity: {res.ai.severity}</Typography>
        <Typography>Sentiment: {res.ai.sentiment}</Typography>
        <Typography>Assigned: {res.assigned_to}</Typography>
      </CardContent></Card>}
    </div>
  )
}
