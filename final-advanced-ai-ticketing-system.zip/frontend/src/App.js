
import React from "react";
import Ticket from "./Ticket";

export default function App(){
  return (
    <div style={{padding:20, background:"#f4f6f8", minHeight:"100vh"}}>
      <h1 style={{textAlign:"center"}}>AI Ticket Dashboard</h1>
      <Ticket/>
    </div>
  )
}
