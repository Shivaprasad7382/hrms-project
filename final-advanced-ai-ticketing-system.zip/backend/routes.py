
from fastapi import APIRouter
from ai_engine import analyze_ticket

router = APIRouter()

employees = [
    {"name":"Rahul","department":"IT","skills":"network","load":2,"availability":"Available"},
    {"name":"Anita","department":"HR","skills":"policy","load":1,"availability":"Available"},
    {"name":"Kiran","department":"Engineering","skills":"server","load":3,"availability":"Busy"}
]

def pick_employee(dept):
    pool = [e for e in employees if e["department"]==dept and e["availability"]=="Available"]
    return sorted(pool, key=lambda x:x["load"])[0]["name"] if pool else "Admin"

@router.post("/ticket")
def create_ticket(data: dict):
    ai = analyze_ticket(data["description"])

    if ai["action"] == "Assign":
        assignee = pick_employee(ai["department"])
    else:
        assignee = "Auto-resolved"

    return {"ai": ai, "assigned_to": assignee}
