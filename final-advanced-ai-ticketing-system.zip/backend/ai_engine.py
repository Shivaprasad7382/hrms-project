
import os, json
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def analyze_ticket(text):
    prompt = f'''
Analyze this support ticket and return STRICT JSON:
Ticket: {text}

Fields:
category (Billing, Bug, Access, HR, Server, DB, Feature, Other)
summary (2 sentences)
severity (Critical, High, Medium, Low)
sentiment (Frustrated, Neutral, Polite)
action (Auto-resolve or Assign)
department
employee (suggest name)
confidence (0-100%)
time_estimate
'''

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":prompt}]
    )

    return json.loads(res.choices[0].message.content)
