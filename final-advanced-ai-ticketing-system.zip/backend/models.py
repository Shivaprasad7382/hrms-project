
from sqlalchemy import Column, Integer, String, Text
from database import Base

class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True)
    description = Column(Text)
    category = Column(String)
    severity = Column(String)
    sentiment = Column(String)
    status = Column(String, default="New")
    assigned_to = Column(String)
    department = Column(String)

class Employee(Base):
    __tablename__ = "employees"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    email = Column(String)
    department = Column(String)
    skills = Column(String)
    load = Column(Integer, default=0)
    availability = Column(String)
