
# Final Advanced AI Ticketing System

## Setup

### Backend
cd backend
python -m pip install -r requirements.txt
copy .env.example .env
# add your OPENAI_API_KEY
python -m uvicorn main:app --reload

### Frontend
cd frontend
npm install
npm start

## Features
- AI structured analysis
- auto resolve + assign
- employee selection logic
- professional UI

## Demo
Show 3 scenarios + explain AI prompt
